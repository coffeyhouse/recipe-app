import React from "react";

export default function Select({ label, options, disabled, value, onChange }) {
    return (
        <label className="form-control w-full max-w-xs">
            {label && (
                <div className="label">
                    <span className="label-text text-base">{label}</span>
                </div>
            )}
            <select
                className="select select-bordered"
                value={value}
                disabled={disabled}
                onChange={onChange}
            >
                <option disabled value="">Pick one</option>
                {options.map((option) => (
                    <option key={option.id} value={option.id}>{option.label}</option>
                ))}
            </select>
        </label>
    );
}
