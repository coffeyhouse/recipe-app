import React from "react";

export default function Input({ label, disabled, type = "text" }) {
    return (
        <label className="form-control w-full max-w-xs">
            {label && (
                <div className="label">
                    <span className="label-text text-base">{label}</span>
                </div>
            )}
            <input
                type={type}
                placeholder="Type here"
                className="input input-bordered w-full max-w-xs"
                disabled={disabled}
            />
        </label>
    );
}
