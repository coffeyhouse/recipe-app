import React from "react";
import { NavLink } from "react-router-dom";
import { FaHome, FaCalendarAlt } from "react-icons/fa";
import { FaCirclePlus } from "react-icons/fa6";

const NavItem = ({ to, Icon, isSpecial = false }) => {
    const baseClasses = "relative text-lg flex flex-col items-center";
    const activeClasses = "text-primary";
    const specialClasses = "text-primary text-5xl shadow rounded-full";

    const ActiveDots = () => (
        <div className="flex justify-center mt-1 gap-1">
            <span className="w-1 h-1 bg-accent rounded-full"></span>
            <span className="w-1 h-1 bg-secondary rounded-full"></span>
            <span className="w-1 h-1 bg-primary rounded-full"></span>
        </div>
    );

    const NotActive = () => (
        <div className="flex justify-center mt-1 gap-1">
            <span className="w-1 h-1 bg-base-100 rounded-full"></span>
            <span className="w-1 h-1 bg-base-100 rounded-full"></span>
            <span className="w-1 h-1 bg-base-100 rounded-full"></span>
        </div>
    )

    return (
        <NavLink
            to={to}
            className={({ isActive }) =>
                isSpecial
                    ? `${baseClasses} ${specialClasses}`
                    : isActive
                        ? `${baseClasses} ${activeClasses}`
                        : baseClasses
            }
        >
            {({ isActive }) => (
                <>
                    <Icon />
                    {isActive && !isSpecial && <ActiveDots />}
                    {!isActive && !isSpecial && <NotActive />}
                </>
            )}
        </NavLink>
    );
};

export default function Footer() {
    const navItems = [
        { to: "/", Icon: FaHome },
        { to: "/meal-plan/1", Icon: FaCalendarAlt },
        { to: "/add", Icon: FaCirclePlus, isSpecial: true },
        { to: "/meal-plan/2", Icon: FaCalendarAlt },
        { to: "/profile", Icon: FaHome },
    ];

    return (
        <div className="flex justify-between py-3 px-6 border-t border-black/10 items-center bg-base-100">
            {navItems.map((item, index) => (
                <NavItem key={index} {...item} />
            ))}
        </div>
    );
}