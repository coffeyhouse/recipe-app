import React from "react";
import { Link } from "react-router-dom";

export default function Header() {
    return (
        <>
            <div className="navbar bg-base-100 shadow z-10 px-6">
                <div className="flex-1">
                    <Link to="/">                    
                        <a className="text font-bold flex gap-2 items-center">                      
                            Meal Planner
                            <div className="flex justify-center mt-1 gap-1">
                                <span className="w-1 h-1 bg-accent rounded-full"></span>
                                <span className="w-1 h-1 bg-secondary rounded-full"></span>
                                <span className="w-1 h-1 bg-primary rounded-full"></span>
                                
                            </div>
                        </a>
                    </Link>
                </div>
                <div className="flex-none">
                    <div className="dropdown dropdown-end">
                        <div tabIndex={0} role="button" className="btn btn-ghost btn-circle avatar">
                            <div className="w-10 rounded-full">
                                <img
                                    alt="Tailwind CSS Navbar component"
                                    src="https://img.daisyui.com/images/stock/photo-1534528741775-53994a69daeb.jpg" />
                            </div>
                        </div>
                        <ul
                            tabIndex={0}
                            className="menu menu-sm dropdown-content bg-base-100 rounded-box z-[1] mt-3 w-52 p-2 shadow">
                            <li>
                                <a className="justify-between">
                                    Ingredients
                                    <span className="badge badge-accent">New</span>
                                </a>
                            </li>
                            <li><a>Categories</a></li>
                            <li><a>Recipes</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </>
    )
}