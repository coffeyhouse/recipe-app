import React from "react";
import Card from "./Card";
import { FaPlus, FaPen } from "react-icons/fa";

export default function MealCard({ mealType, meal, side, color, source, icon }) {
    const randomImageNumber = Math.floor(Math.random() * 1000);

    return (
        <div className="flex flex-col gap-2">
            {mealType && (
                <p className="font-bold flex flex-col text-sm">
                    {mealType} <span className={`h-[2px] w-8 bg-${color} mt-[2px]`}></span>
                </p>
            )}
            <Card>
                <div className="flex gap-4 h-24 items-center">
                    <div className="relative w-20 h-20">
                        <div className={`absolute inset-0 bg-${color} transform rotate-6 rounded-xl z-0`}></div>
                        {meal && (
                            <img
                                src={`https://picsum.photos/500/500?random=${randomImageNumber}`}
                                className="absolute inset-0 h-full w-full object-cover rounded-xl z-10"
                            />
                        )}
                    </div>
                    <div className="flex flex-col justify-center items-start flex-1">
                        {source && <span className="text-[10px] uppercase text-black/60 mb-2"><span className="font-bold">{source.author}</span> • {source.book}</span>}
                        <span className="font-bold">{meal || "Nothing planned"}</span>
                        {side && <span className="text-black/60 text-xs">with {side}</span>}
                    </div>
                    <button className="btn flex items-center">
                        {icon ? icon : meal ? <FaPen /> : <FaPlus />}
                    </button>
                </div>
            </Card>
        </div>
    );
}
