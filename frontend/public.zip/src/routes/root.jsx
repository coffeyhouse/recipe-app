import { Outlet } from "react-router-dom";
import Header from "../components/Header";
import Footer from "../components/Footer";

export default function Root() {
    return (
        <div className="flex flex-col h-screen max-h-screen bg-base-200 text-base-content">
            <Header />
            <div className="grow overflow-auto p-6 pb-24">
                <Outlet />
            </div>
            <Footer />
        </div>
    );
}
