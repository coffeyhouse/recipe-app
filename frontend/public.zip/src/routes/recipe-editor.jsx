import React, { useState } from "react";
import Input from "../components/Input";
import Select from "../components/Select";

export default function RecipeEditor() {
    const [includeAuthor, setIncludeAuthor] = useState(false);
    const [selectedAuthor, setSelectedAuthor] = useState("");
    const [selectedBook, setSelectedBook] = useState("");
    const [selectedDifficulty, setSelectedDifficulty] = useState("");
    const [selectedType, setSelectedType] = useState("");
    const [selectedCountry, setSelectedCountry] = useState("");
    const [sourceType, setSourceType] = useState("none");

    const authorOptions = [
        { id: 1, label: "Person 1" },
        { id: 2, label: "Person 2" },
        { id: 3, label: "Person 3" },
        { id: 4, label: "Person 4" },
        { id: 5, label: "Person 5" },
    ];

    const bookOptions = [
        { id: 1, label: "Book 1", authorId: 1 },
        { id: 2, label: "Book 2", authorId: 1 },
        { id: 3, label: "Book 3", authorId: 2 },
        { id: 4, label: "Book 4", authorId: 2 },
        { id: 5, label: "Book 5", authorId: 3 },
        { id: 6, label: "Book 6", authorId: 3 },
        { id: 7, label: "Book 7", authorId: 4 },
        { id: 8, label: "Book 8", authorId: 5 },
        { id: 9, label: "Book 9", authorId: 5 },
    ];

    const handleIncludeAuthorChange = (event) => {
        setIncludeAuthor(event.target.checked);
        if (!event.target.checked) {
            setSelectedAuthor(""); // Reset author selection when checkbox is unchecked
        }
    };

    const handleAuthorChange = (event) => {
        setSelectedAuthor(event.target.value);
        setSelectedBook(""); // Reset book selection when author changes
    };

    const handleBookChange = (event) => {
        setSelectedBook(event.target.value);
    };

    const handleDifficultyChange = (event) => {
        setSelectedDifficulty(event.target.value);
    };

    const handleTypeChange = (event) => {
        setSelectedType(event.target.value);
    };

    const handleCountryChange = (event) => {
        setSelectedCountry(event.target.value);
    };

    const handleSourceTypeChange = (event) => {
        setSourceType(event.target.value);
    };

    const filteredBookOptions = bookOptions.filter(book => book.authorId === parseInt(selectedAuthor));

    return (
        <>
            <div className="flex flex-col gap-4 py-2 px-6">
                <Input label="Name" />
                <div className="form-control max-w-xs">
                    <label className="label cursor-pointer">
                        <span className="label-text text-base">Include Author</span>
                        <input
                            type="checkbox"
                            className="checkbox"
                            checked={includeAuthor}
                            onChange={handleIncludeAuthorChange}
                        />
                    </label>
                </div>
                <Select
                    label="Author"
                    options={authorOptions}
                    disabled={!includeAuthor}
                    value={selectedAuthor}
                    onChange={handleAuthorChange}
                />
                <div className="form-control  max-w-xs">
                    <label className="label cursor-pointer">
                        <span className="label-text">Book</span>
                        <input
                            type="radio"
                            name="sourceType"
                            value="book"
                            className="radio"
                            checked={sourceType === "book"}
                            onChange={handleSourceTypeChange}
                            disabled={!selectedAuthor}
                        />
                    </label>
                </div>
                <div className="form-control  max-w-xs">
                    <label className="label cursor-pointer">
                        <span className="label-text">Online</span>
                        <input
                            type="radio"
                            name="sourceType"
                            value="online"
                            className="radio"
                            checked={sourceType === "online"}
                            onChange={handleSourceTypeChange}
                            disabled={!selectedAuthor}
                        />
                    </label>
                </div>
                <div className="form-control  max-w-xs">
                    <label className="label cursor-pointer">
                        <span className="label-text">None</span>
                        <input
                            type="radio"
                            name="sourceType"
                            value="none"
                            className="radio"
                            checked={sourceType === "none"}
                            onChange={handleSourceTypeChange}
                            disabled={!selectedAuthor}
                        />
                    </label>
                </div>

                <Select
                    label="Book"
                    options={filteredBookOptions}
                    disabled={!selectedAuthor || sourceType !== "book"}
                    value={selectedBook}
                    onChange={handleBookChange}
                />
                <Input label="#" type="number" disabled={sourceType !== "book" || !selectedBook} />
                <Input label="URL" disabled={sourceType !== "online"} />
                <Input label="Time" type="number" />
                <Select
                    label="Difficulty"
                    options={[
                        { id: 'easy', label: 'Easy' },
                        { id: 'medium', label: 'Medium' },
                        { id: 'hard', label: 'Hard' },
                    ]}
                    disabled={false}
                    value={selectedDifficulty}
                    onChange={handleDifficultyChange}
                />
                <Select
                    label="Type"
                    options={[
                        { id: 'main', label: 'Main' },
                        { id: 'side', label: 'Side' },
                    ]}
                    disabled={false}
                    value={selectedType}
                    onChange={handleTypeChange}
                />
                <Input label="Image URL" />
                <Input label="Serving" type="number" />
                <Select
                    label="Country"
                    options={[
                        { id: 'usa', label: 'USA' },
                        { id: 'canada', label: 'Canada' },
                        { id: 'mexico', label: 'Mexico' },
                    ]}
                    disabled={false}
                    value={selectedCountry}
                    onChange={handleCountryChange}
                />
            </div>
        </>
    );
}
