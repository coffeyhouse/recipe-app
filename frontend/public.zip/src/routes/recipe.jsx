import React from "react";
import { FaHeart } from "react-icons/fa";

export default function Recipe() {
    // Dummy data for POC
    const recipe = {
        image: "https://picsum.photos/500/300",
        title: "Toast with egg and avocado",
        details: {
            calories: 345,
            weight: 250,
            rating: 4.7,
            time: 15,
        },
        tags: ["Breakfast", "Fast", "Easy"],
        ingredients: [
            { name: "Eggs", quantity: "3 pc" },
            { name: "Toast bread", quantity: "2 pc" },
            { name: "Avocado", quantity: "1 pc" },
            { name: "Tomato", quantity: "1/2 pc" },
            { name: "Cheese", quantity: "70 g" },
        ],
    };

    return (
        <div className="p-4">
            <div className="relative">
                <img src={recipe.image} alt={recipe.title} className="w-full h-64 object-cover rounded" />
                <div className="absolute top-2 left-2 bg-white rounded-full p-1">
                    <FaHeart className="text-gray-500" />
                </div>
            </div>
            <h1 className="text-2xl font-bold mt-4">{recipe.title}</h1>
            <div className="flex gap-4 mt-2">
                <div className="flex flex-col items-center">
                    <span className="font-bold">{recipe.details.calories}</span>
                    <span className="text-xs text-gray-500">kcal</span>
                </div>
                <div className="flex flex-col items-center">
                    <span className="font-bold">{recipe.details.weight}</span>
                    <span className="text-xs text-gray-500">grams</span>
                </div>
                <div className="flex flex-col items-center">
                    <span className="font-bold">{recipe.details.rating}</span>
                    <span className="text-xs text-gray-500">rating</span>
                </div>
                <div className="flex flex-col items-center">
                    <span className="font-bold">{recipe.details.time}</span>
                    <span className="text-xs text-gray-500">minutes</span>
                </div>
            </div>
            <div className="flex gap-2 mt-4">
                {recipe.tags.map((tag, index) => (
                    <span key={index} className="bg-green-100 text-green-700 text-xs font-semibold px-2 py-1 rounded">
                        {tag}
                    </span>
                ))}
            </div>
            <h2 className="text-xl font-semibold mt-4">Ingredients</h2>
            <ul className="list-disc list-inside mt-2">
                {recipe.ingredients.map((ingredient, index) => (
                    <li key={index}>
                        {ingredient.name} - {ingredient.quantity}
                    </li>
                ))}
            </ul>
            <button className="mt-4 bg-green-500 text-white font-semibold py-2 px-4 rounded hover:bg-green-600">
                Start Cooking
            </button>
        </div>
    );
}
